import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ArrowRight, Handshake, Building2, Code2, Globe } from "lucide-react"
import Link from "next/link"

const partnerTypes = [
  {
    icon: Building2,
    title: "System Integrators",
    description: "Partner with us to bring AI agent orchestration to your enterprise clients. Get certified, access our partner portal, and co-sell solutions.",
  },
  {
    icon: Code2,
    title: "Technology Partners",
    description: "Integrate your tools and services with Agentivity. Build connectors, extend our platform, and reach our growing user base.",
  },
  {
    icon: Globe,
    title: "Resellers & Distributors",
    description: "Bring Agentivity to new markets and regions. Benefit from volume pricing, marketing support, and dedicated partner success.",
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24">
        {/* Hero */}
        <section className="px-6 py-16 md:py-24">
          <div className="mx-auto max-w-4xl text-center">
            <h1 className="text-balance text-4xl font-bold tracking-tight md:text-5xl">
              We&apos;re building the future of{" "}
              <span className="bg-gradient-to-r from-accent to-accent/60 bg-clip-text text-transparent">
                AI collaboration
              </span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground">
              Agentivity was born from a simple idea: AI agents are more powerful when they work together. 
              We&apos;re on a mission to make AI orchestration accessible to every business.
            </p>
          </div>
        </section>

        {/* Mission */}
        <section className="px-6 py-16 border-t border-border/50">
          <div className="mx-auto max-w-4xl">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-2xl font-bold md:text-3xl">Our Mission</h2>
                <p className="mt-4 text-muted-foreground">
                  We believe that the next wave of AI adoption will be driven by teams of specialized agents 
                  working together — not single-purpose chatbots. Agentivity provides the platform to design, 
                  deploy, and manage these agent teams at scale.
                </p>
                <p className="mt-4 text-muted-foreground">
                  Our visual-first approach means anyone can build sophisticated AI workflows, 
                  while our powerful engine ensures reliability and control for the most demanding use cases.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-xl border border-border/50 bg-card p-6 text-center">
                  <p className="text-3xl font-bold text-accent">50+</p>
                  <p className="mt-1 text-sm text-muted-foreground">Companies using Agentivity</p>
                </div>
                <div className="rounded-xl border border-border/50 bg-card p-6 text-center">
                  <p className="text-3xl font-bold text-accent">1M+</p>
                  <p className="mt-1 text-sm text-muted-foreground">Agent tasks executed</p>
                </div>
                <div className="rounded-xl border border-border/50 bg-card p-6 text-center">
                  <p className="text-3xl font-bold text-accent">99.9%</p>
                  <p className="mt-1 text-sm text-muted-foreground">Uptime SLA</p>
                </div>
                <div className="rounded-xl border border-border/50 bg-card p-6 text-center">
                  <p className="text-3xl font-bold text-accent">24/7</p>
                  <p className="mt-1 text-sm text-muted-foreground">Support available</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Partnership */}
        <section className="px-6 py-16 border-t border-border/50">
          <div className="mx-auto max-w-4xl">
            <div className="text-center mb-12">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-accent/10 text-accent mb-4">
                <Handshake className="h-6 w-6" />
              </div>
              <h2 className="text-2xl font-bold md:text-3xl">Partner with Us</h2>
              <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
                Join our partner ecosystem and help businesses unlock the power of AI agent teams. 
                We offer programs for integrators, technology partners, and resellers.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {partnerTypes.map((partner) => (
                <div
                  key={partner.title}
                  className="rounded-xl border border-border/50 bg-card p-6 hover:border-accent/50 transition-colors"
                >
                  <partner.icon className="h-8 w-8 text-accent mb-4" />
                  <h3 className="font-semibold text-lg">{partner.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{partner.description}</p>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <Link href="/contact">
                <Button size="lg" className="gap-2">
                  Become a Partner
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Open Source */}
        <section className="px-6 py-16 border-t border-border/50">
          <div className="mx-auto max-w-4xl text-center">
            <h2 className="text-2xl font-bold md:text-3xl">Open Source First</h2>
            <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
              We believe in transparency and community-driven development. Our core agent framework 
              is open source, and we actively contribute to the AI ecosystem.
            </p>
            <div className="mt-8">
              <Link
                href="https://github.com/agentivity"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="outline" size="lg" className="gap-2">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path fillRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clipRule="evenodd" />
                  </svg>
                  View on GitHub
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
