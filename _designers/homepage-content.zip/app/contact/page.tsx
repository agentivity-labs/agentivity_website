"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Mail, MessageSquare, Building2, ArrowRight } from "lucide-react"

const inquiryTypes = [
  { id: "demo", label: "Request a demo", icon: MessageSquare },
  { id: "services", label: "Professional services", icon: Building2 },
  { id: "partnership", label: "Partnership inquiry", icon: Mail },
]

export default function ContactPage() {
  const [selectedType, setSelectedType] = useState("demo")
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24">
        <section className="px-6 py-16 md:py-24">
          <div className="mx-auto max-w-4xl">
            <div className="text-center mb-12">
              <h1 className="text-balance text-4xl font-bold tracking-tight md:text-5xl">
                Let&apos;s talk
              </h1>
              <p className="mt-4 text-lg text-muted-foreground">
                Whether you want a demo, need professional services, or are interested in partnering — we&apos;d love to hear from you.
              </p>
            </div>

            {submitted ? (
              <div className="rounded-2xl border border-border/50 bg-card p-12 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-accent/10 text-accent mb-6">
                  <Mail className="h-8 w-8" />
                </div>
                <h2 className="text-2xl font-bold">Thank you!</h2>
                <p className="mt-4 text-muted-foreground">
                  We&apos;ve received your message and will get back to you within 24 hours.
                </p>
              </div>
            ) : (
              <div className="grid md:grid-cols-5 gap-8">
                {/* Inquiry type selection */}
                <div className="md:col-span-2 space-y-4">
                  <h2 className="font-semibold text-lg">How can we help?</h2>
                  {inquiryTypes.map((type) => (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => setSelectedType(type.id)}
                      className={`w-full flex items-center gap-4 rounded-xl border p-4 text-left transition-all ${
                        selectedType === type.id
                          ? "border-accent bg-accent/5"
                          : "border-border/50 bg-card hover:border-border"
                      }`}
                    >
                      <type.icon className={`h-5 w-5 ${selectedType === type.id ? "text-accent" : "text-muted-foreground"}`} />
                      <span className={selectedType === type.id ? "font-medium" : "text-muted-foreground"}>
                        {type.label}
                      </span>
                    </button>
                  ))}

                  <div className="pt-6 border-t border-border/50 mt-6">
                    <p className="text-sm text-muted-foreground">
                      Prefer email? Reach us directly at{" "}
                      <a href="mailto:hello@agentivity.io" className="text-accent hover:underline">
                        hello@agentivity.io
                      </a>
                    </p>
                  </div>
                </div>

                {/* Contact form */}
                <form onSubmit={handleSubmit} className="md:col-span-3 rounded-2xl border border-border/50 bg-card p-6 md:p-8">
                  <div className="grid gap-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First name</Label>
                        <Input id="firstName" placeholder="Jane" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last name</Label>
                        <Input id="lastName" placeholder="Smith" required />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Work email</Label>
                      <Input id="email" type="email" placeholder="jane@company.com" required />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="company">Company</Label>
                      <Input id="company" placeholder="Acme Inc." required />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Message</Label>
                      <textarea
                        id="message"
                        className="flex min-h-[120px] w-full rounded-md border border-input bg-input px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring resize-none"
                        placeholder={
                          selectedType === "demo"
                            ? "Tell us about your use case and what you&apos;d like to see in a demo..."
                            : selectedType === "services"
                            ? "Describe your project and how we can help..."
                            : "Tell us about your partnership idea..."
                        }
                        required
                      />
                    </div>

                    <Button type="submit" size="lg" className="w-full gap-2">
                      Send message
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
