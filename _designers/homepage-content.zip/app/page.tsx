import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { VisualPreview } from "@/components/visual-preview"
import { TeamShowcase } from "@/components/team-showcase"
import { Promises } from "@/components/promises"
import { Features } from "@/components/features"
import { ForWho } from "@/components/for-who"
import { Stats } from "@/components/stats"
import { CTA } from "@/components/cta"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <VisualPreview />
        <TeamShowcase />
        <Promises />
        <Features />
        <ForWho />
        <Stats />
        <CTA />
      </main>
      <Footer />
    </div>
  )
}
