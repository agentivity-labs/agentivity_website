import { Users, Bot, Brain, Zap, MessageSquare, FileSearch, Mail, ShoppingCart, HeadphonesIcon, TrendingUp } from "lucide-react"

const teamExamples = [
  {
    name: "Customer Success Squad",
    description: "Handle support tickets, qualify leads, and nurture relationships 24/7",
    agents: [
      { icon: HeadphonesIcon, role: "Support Agent", color: "bg-blue-500/20 text-blue-400" },
      { icon: MessageSquare, role: "Chat Specialist", color: "bg-green-500/20 text-green-400" },
      { icon: TrendingUp, role: "Success Manager", color: "bg-amber-500/20 text-amber-400" },
    ],
    useCase: "Reduced response time by 85%",
  },
  {
    name: "Content Factory",
    description: "Research, write, review and publish content at scale",
    agents: [
      { icon: FileSearch, role: "Researcher", color: "bg-purple-500/20 text-purple-400" },
      { icon: Brain, role: "Writer", color: "bg-pink-500/20 text-pink-400" },
      { icon: Bot, role: "Editor", color: "bg-cyan-500/20 text-cyan-400" },
    ],
    useCase: "10x content output",
  },
  {
    name: "Sales Dream Team",
    description: "Prospect, qualify, engage and close deals automatically",
    agents: [
      { icon: Mail, role: "Outreach Agent", color: "bg-orange-500/20 text-orange-400" },
      { icon: Users, role: "Qualifier", color: "bg-teal-500/20 text-teal-400" },
      { icon: ShoppingCart, role: "Closer", color: "bg-rose-500/20 text-rose-400" },
    ],
    useCase: "3x qualified leads",
  },
]

export function TeamShowcase() {
  return (
    <section id="teams" className="px-6 py-24 md:py-32">
      <div className="mx-auto max-w-7xl">
        <div className="text-center">
          <p className="text-sm font-medium uppercase tracking-wider text-accent">Build Your AI Company</p>
          <h2 className="mt-4 text-balance text-3xl font-bold tracking-tight md:text-5xl">
            Assemble teams like you&apos;d build a startup
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-lg text-muted-foreground">
            Each agent has a role, memory, and expertise. Together, they collaborate, hand off tasks, and get things done — just like a real team.
          </p>
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {teamExamples.map((team) => (
            <div
              key={team.name}
              className="group relative overflow-hidden rounded-2xl border border-border/50 bg-card p-6 transition-all hover:border-accent/50 hover:shadow-lg hover:shadow-accent/5"
            >
              {/* Team header */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold">{team.name}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{team.description}</p>
              </div>

              {/* Agent avatars */}
              <div className="mb-6 flex flex-col gap-3">
                {team.agents.map((agent) => (
                  <div key={agent.role} className="flex items-center gap-3">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-full ${agent.color}`}>
                      <agent.icon className="h-5 w-5" />
                    </div>
                    <span className="text-sm font-medium">{agent.role}</span>
                  </div>
                ))}
              </div>

              {/* Connection lines visualization */}
              <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-10 group-hover:opacity-20 transition-opacity">
                <svg width="60" height="80" viewBox="0 0 60 80" fill="none" className="text-accent">
                  <path d="M10 10 L50 40 L10 70" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" />
                  <circle cx="10" cy="10" r="4" fill="currentColor" />
                  <circle cx="50" cy="40" r="4" fill="currentColor" />
                  <circle cx="10" cy="70" r="4" fill="currentColor" />
                </svg>
              </div>

              {/* Result badge */}
              <div className="flex items-center gap-2 rounded-full bg-accent/10 px-3 py-1.5 text-sm text-accent w-fit">
                <Zap className="h-3.5 w-3.5" />
                {team.useCase}
              </div>
            </div>
          ))}
        </div>

        <p className="mt-12 text-center text-muted-foreground">
          These are just examples. With Agentivity, you design the team that fits{" "}
          <span className="text-foreground font-medium">your</span> business.
        </p>
      </div>
    </section>
  )
}
