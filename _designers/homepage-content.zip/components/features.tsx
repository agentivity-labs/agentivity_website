import { 
  Workflow, 
  Brain, 
  GitBranch, 
  UserPlus, 
  MessageSquare, 
  Sparkles, 
  Bot 
} from "lucide-react"

const features = [
  {
    icon: Workflow,
    title: "Visual Workflow Editor",
    description: "Build your automations with drag-and-drop. Connect agents, tools and conditions on an intuitive canvas. Visualize execution in real-time, node by node."
  },
  {
    icon: Brain,
    title: "Intelligent Agents with Memory",
    description: "Each agent remembers the context of your past conversations. It learns from its interactions and improves over time — without you having to reconfigure everything each call."
  },
  {
    icon: GitBranch,
    title: "Multi-Mode Agent Teams",
    description: "Choose how your agents collaborate: sequential handoffs, parallel processing with merged results, dynamic delegation, group discussion, or manager-led coordination."
  },
  {
    icon: UserPlus,
    title: "Built-in Human Interaction",
    description: "Your agents can submit forms, request approval, or simply notify you of a completed step — directly in the interface, without leaving context."
  },
  {
    icon: MessageSquare,
    title: "Real-Time Chat with Your Agents",
    description: "Converse with your agents while they work. Follow their progress, ask questions, adjust their course — like with a collaborator."
  },
  {
    icon: Sparkles,
    title: "Prompt Studio",
    description: "Write, test and optimize your prompts with dedicated tools. Compare versions, measure performance, and let AI suggest improvements."
  },
  {
    icon: Bot,
    title: "AI Assistant in the Editor",
    description: "Build faster with an assistant that understands your current workflow. It suggests steps, configures nodes for you and answers your business questions — without leaving the editor."
  }
]

export function Features() {
  return (
    <section id="features" className="border-t border-border/50 px-6 py-24">
      <div className="mx-auto max-w-7xl">
        <div className="mb-16 text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
            Everything you need to orchestrate AI agents
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            A complete platform to design, test and deploy intelligent automations.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group rounded-2xl border border-border/50 bg-card/30 p-6 transition-all hover:border-accent/30 hover:bg-card/50"
            >
              <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-accent">
                <feature.icon className="h-5 w-5" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
