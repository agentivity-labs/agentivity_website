import { Bot, ArrowRight, MessageSquare, Database, Zap } from "lucide-react"

export function VisualPreview() {
  return (
    <section className="px-6 py-24 md:py-32 overflow-hidden">
      <div className="mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <p className="text-sm font-medium uppercase tracking-wider text-accent">Visual Workflow Editor</p>
          <h2 className="mt-4 text-balance text-3xl font-bold tracking-tight md:text-5xl">
            See your agents work together
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-lg text-muted-foreground">
            Design workflows visually. Watch agents collaborate in real-time. No code required to get started.
          </p>
        </div>

        {/* Visual workflow mockup */}
        <div className="relative rounded-2xl border border-border/50 bg-card/50 p-4 md:p-8 overflow-hidden">
          {/* Glow effect */}
          <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-accent/5 pointer-events-none" />
          
          {/* Workflow visualization */}
          <div className="relative flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8 py-8">
            {/* Trigger node */}
            <div className="flex flex-col items-center gap-2">
              <div className="flex h-16 w-16 items-center justify-center rounded-xl border border-green-500/30 bg-green-500/10 text-green-400">
                <MessageSquare className="h-7 w-7" />
              </div>
              <span className="text-xs text-muted-foreground">Trigger</span>
            </div>

            <ArrowRight className="h-5 w-5 text-muted-foreground hidden md:block" />
            <div className="h-5 w-px bg-muted-foreground md:hidden" />

            {/* Agent 1 */}
            <div className="flex flex-col items-center gap-2">
              <div className="relative">
                <div className="flex h-16 w-16 items-center justify-center rounded-xl border border-accent/30 bg-accent/10 text-accent">
                  <Bot className="h-7 w-7" />
                </div>
                <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-green-500 animate-pulse" />
              </div>
              <span className="text-xs text-muted-foreground">Analyzer</span>
            </div>

            <ArrowRight className="h-5 w-5 text-muted-foreground hidden md:block" />
            <div className="h-5 w-px bg-muted-foreground md:hidden" />

            {/* Agent 2 */}
            <div className="flex flex-col items-center gap-2">
              <div className="relative">
                <div className="flex h-16 w-16 items-center justify-center rounded-xl border border-blue-500/30 bg-blue-500/10 text-blue-400">
                  <Database className="h-7 w-7" />
                </div>
                <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-green-500 animate-pulse" style={{ animationDelay: "0.5s" }} />
              </div>
              <span className="text-xs text-muted-foreground">Data Agent</span>
            </div>

            <ArrowRight className="h-5 w-5 text-muted-foreground hidden md:block" />
            <div className="h-5 w-px bg-muted-foreground md:hidden" />

            {/* Agent 3 */}
            <div className="flex flex-col items-center gap-2">
              <div className="relative">
                <div className="flex h-16 w-16 items-center justify-center rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-400">
                  <Bot className="h-7 w-7" />
                </div>
                <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-green-500 animate-pulse" style={{ animationDelay: "1s" }} />
              </div>
              <span className="text-xs text-muted-foreground">Responder</span>
            </div>

            <ArrowRight className="h-5 w-5 text-muted-foreground hidden md:block" />
            <div className="h-5 w-px bg-muted-foreground md:hidden" />

            {/* Output */}
            <div className="flex flex-col items-center gap-2">
              <div className="flex h-16 w-16 items-center justify-center rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-400">
                <Zap className="h-7 w-7" />
              </div>
              <span className="text-xs text-muted-foreground">Action</span>
            </div>
          </div>

          {/* Live activity indicator */}
          <div className="mt-8 flex items-center justify-center gap-3 text-sm text-muted-foreground">
            <span className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
              Live collaboration
            </span>
            <span className="text-border">|</span>
            <span>3 agents active</span>
            <span className="text-border">|</span>
            <span>12 tasks completed</span>
          </div>
        </div>
      </div>
    </section>
  )
}
