import { Button } from "@/components/ui/button"
import { ArrowRight, Play, Sparkles } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <section className="relative overflow-hidden px-6 pt-32 pb-24 md:pt-40 md:pb-32">
      {/* Gradient orb background */}
      <div className="pointer-events-none absolute top-0 right-0 h-[600px] w-[600px] translate-x-1/3 -translate-y-1/4 rounded-full bg-accent/30 blur-[120px]" />
      <div className="pointer-events-none absolute bottom-0 left-0 h-[400px] w-[400px] -translate-x-1/3 translate-y-1/4 rounded-full bg-accent/20 blur-[100px]" />
      
      <div className="relative mx-auto max-w-5xl text-center">
        {/* Badge */}
        <div className="mb-8 flex justify-center">
          <div className="flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-4 py-1.5 text-sm text-accent">
            <Sparkles className="h-4 w-4" />
            Build your AI workforce in minutes
          </div>
        </div>

        <h1 className="text-balance text-4xl font-bold tracking-tight md:text-6xl lg:text-7xl">
          Assemble{" "}
          <span className="bg-gradient-to-r from-accent to-accent/60 bg-clip-text text-transparent">
            AI agent teams
          </span>
          {" "}like you&apos;d build a company
        </h1>
        
        <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground md:text-xl">
          Stop building single-purpose chatbots. Create teams of specialized agents that collaborate, 
          learn, and get work done — exactly like your best employees would.
        </p>

        <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Button size="lg" className="gap-2 h-12 px-6 text-base">
            Start building for free
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="lg" className="gap-2 h-12 px-6 text-base">
            <Play className="h-4 w-4" />
            Watch 2-min demo
          </Button>
        </div>

        {/* Social proof */}
        <div className="mt-12 flex flex-col items-center gap-4">
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <svg key={i} className="h-5 w-5 text-amber-400 fill-amber-400" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            ))}
          </div>
          <p className="text-sm text-muted-foreground">
            Trusted by 50+ teams automating their workflows
          </p>
        </div>

        {/* Quick benefits */}
        <div className="mt-16 grid grid-cols-1 gap-4 text-sm md:grid-cols-3">
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            No code required to start
          </div>
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            Human-in-the-loop control
          </div>
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            <Link href="https://github.com/agentivity" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition-colors">
              Open source core
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
