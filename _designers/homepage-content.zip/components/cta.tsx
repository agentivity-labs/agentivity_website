import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles } from "lucide-react"
import Link from "next/link"

export function CTA() {
  return (
    <section className="px-6 py-24 md:py-32">
      <div className="mx-auto max-w-4xl">
        <div className="relative overflow-hidden rounded-3xl border border-accent/20 bg-gradient-to-br from-accent/10 via-background to-accent/5 px-8 py-16 text-center md:px-16 md:py-24">
          {/* Decorative elements */}
          <div className="pointer-events-none absolute top-0 right-0 h-64 w-64 translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/20 blur-[80px]" />
          <div className="pointer-events-none absolute bottom-0 left-0 h-48 w-48 -translate-x-1/2 translate-y-1/2 rounded-full bg-accent/15 blur-[60px]" />
          
          <div className="relative">
            <div className="mb-6 flex justify-center">
              <div className="flex items-center gap-2 rounded-full border border-accent/30 bg-accent/10 px-4 py-1.5 text-sm text-accent">
                <Sparkles className="h-4 w-4" />
                Free to get started
              </div>
            </div>

            <h2 className="text-balance text-3xl font-bold tracking-tight md:text-5xl">
              Ready to build your AI team?
            </h2>
            
            <p className="mx-auto mt-6 max-w-xl text-pretty text-lg text-muted-foreground">
              Join 50+ companies already using Agentivity to automate their workflows. 
              Start free, scale when you&apos;re ready.
            </p>

            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button size="lg" className="gap-2 h-12 px-8 text-base">
                Start building free
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Link href="/contact">
                <Button variant="outline" size="lg" className="h-12 px-8 text-base">
                  Talk to us
                </Button>
              </Link>
            </div>

            <p className="mt-8 text-sm text-muted-foreground">
              No credit card required. Full access to the visual editor.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
