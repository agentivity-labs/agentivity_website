import { Zap, Database, Shield, Cpu, Monitor } from "lucide-react"

const stats = [
  {
    icon: Zap,
    text: "Deployment in minutes"
  },
  {
    icon: Database,
    text: "Persistent memory between sessions"
  },
  {
    icon: Shield,
    text: "Human control at every critical step"
  },
  {
    icon: Cpu,
    text: "Compatible with major LLMs"
  },
  {
    icon: Monitor,
    text: "Desktop & web interface"
  }
]

export function Stats() {
  return (
    <section className="border-t border-border/50 px-6 py-16">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12">
          {stats.map((stat, index) => (
            <div key={index} className="flex items-center gap-3 text-muted-foreground">
              <stat.icon className="h-5 w-5 text-accent" />
              <span className="text-sm font-medium">{stat.text}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
