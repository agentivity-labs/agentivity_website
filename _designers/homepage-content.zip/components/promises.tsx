import { Clock, Users, UserCheck } from "lucide-react"

const promises = [
  {
    icon: Clock,
    title: "Automate what costs you time",
    description: "Design intelligent pipelines that chain steps automatically: data collection, analysis, writing, validation, notification. Your agents work while you focus on what matters."
  },
  {
    icon: Users,
    title: "Make your agents collaborate like a real team",
    description: "A single agent has its limits. A team of coordinating agents has almost none. Agentivity orchestrates your agents in sequence, parallel, or dynamic delegation — whatever your use case demands."
  },
  {
    icon: UserCheck,
    title: "Stay in the loop, at the right moment",
    description: "Agentivity knows when a human decision is needed. It pauses the process, asks you the right question, and resumes automatically once you&apos;ve answered. No over-interruptions, no black box."
  }
]

export function Promises() {
  return (
    <section id="how-it-works" className="border-t border-border/50 px-6 py-24">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-8 md:grid-cols-3">
          {promises.map((promise, index) => (
            <div
              key={index}
              className="group rounded-2xl border border-border/50 bg-card/50 p-8 transition-all hover:border-accent/50 hover:bg-card"
            >
              <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-xl bg-accent/10 text-accent transition-colors group-hover:bg-accent/20">
                <promise.icon className="h-6 w-6" />
              </div>
              <h3 className="mb-3 text-xl font-semibold">{promise.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{promise.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
