import { Briefcase, Code2, Plug, BarChart3 } from "lucide-react"

const audiences = [
  {
    icon: Briefcase,
    profile: "Business Teams",
    benefit: "Automate your processes without writing a single line of code"
  },
  {
    icon: Code2,
    profile: "AI Developers",
    benefit: "A design and testing environment for your LLM agents"
  },
  {
    icon: Plug,
    profile: "Integrators",
    benefit: "Connect Agentivity to your existing systems via an open API"
  },
  {
    icon: BarChart3,
    profile: "Managers & Ops",
    benefit: "Real-time visibility on every execution, every decision"
  }
]

export function ForWho() {
  return (
    <section id="for-who" className="border-t border-border/50 px-6 py-24">
      <div className="mx-auto max-w-7xl">
        <div className="mb-16 text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
            Built for everyone who wants to leverage AI
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Whether you code or not, Agentivity adapts to how you work.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {audiences.map((audience, index) => (
            <div
              key={index}
              className="relative overflow-hidden rounded-2xl border border-border/50 bg-gradient-to-b from-card/50 to-card/20 p-6 transition-all hover:border-accent/50"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-accent/10 text-accent">
                <audience.icon className="h-6 w-6" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">{audience.profile}</h3>
              <p className="text-sm text-muted-foreground">{audience.benefit}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
