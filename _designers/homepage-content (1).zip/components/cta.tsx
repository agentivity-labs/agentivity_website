import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export function CTA() {
  return (
    <section className="px-6 py-24 md:py-32 relative">
      <div className="mx-auto max-w-4xl">
        <div className="relative overflow-hidden rounded-lg border border-border bg-card/30 backdrop-blur">
          {/* Terminal header */}
          <div className="flex items-center justify-between border-b border-border px-4 py-3 bg-card/80">
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500/50" />
                <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50" />
                <div className="w-2.5 h-2.5 rounded-full bg-green-500/50" />
              </div>
              <span className="font-mono text-xs text-muted-foreground ml-2">getting-started.sh</span>
            </div>
          </div>
          
          {/* Content */}
          <div className="px-8 py-12 md:px-16 md:py-16 text-center relative">
            {/* Glow */}
            <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/10 rounded-full blur-[100px]" />
            
            <div className="relative">
              <div className="mb-6 flex justify-center">
                <div className="font-mono text-xs text-muted-foreground px-3 py-1.5 rounded bg-secondary/50 border border-border">
                  <span className="text-primary">$</span> npx agentivity init --free
                </div>
              </div>

              <h2 className="text-balance text-3xl font-bold tracking-tight md:text-4xl">
                Ready to build your{" "}
                <span className="text-primary">AI team</span>?
              </h2>
              
              <p className="mx-auto mt-6 max-w-xl text-muted-foreground">
                Join 50+ companies already using Agentivity. 
                Start free, scale when you&apos;re ready.
              </p>

              <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Button size="lg" className="gap-2 h-12 px-8 font-mono text-sm bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(0,212,255,0.4)] transition-all">
                  Start building
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Link href="/contact">
                  <Button variant="outline" size="lg" className="h-12 px-8 font-mono text-sm border-border hover:border-primary hover:text-primary transition-all">
                    Talk to us
                  </Button>
                </Link>
              </div>

              <p className="mt-8 font-mono text-xs text-muted-foreground">
                <span className="text-green-400">{">"}</span> No credit card required
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
