import { Button } from "@/components/ui/button"
import { ArrowRight, Play } from "lucide-react"
import Link from "next/link"
import { AgentNetwork } from "./agent-network"

export function Hero() {
  return (
    <section className="relative overflow-hidden px-6 pt-32 pb-16 md:pt-40 md:pb-24">
      {/* Grid background */}
      <div className="absolute inset-0 grid-pattern opacity-20" />
      
      {/* Glow orbs */}
      <div className="pointer-events-none absolute top-20 right-1/4 h-[500px] w-[500px] rounded-full bg-primary/10 blur-[150px] animate-pulse-glow" />
      <div className="pointer-events-none absolute bottom-0 left-1/4 h-[300px] w-[300px] rounded-full bg-primary/5 blur-[100px]" />
      
      <div className="relative mx-auto max-w-6xl">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-8 items-center">
          {/* Left content */}
          <div className="text-center lg:text-left">
            {/* Terminal badge */}
            <div className="mb-8 inline-flex">
              <div className="flex items-center gap-2 rounded border border-border bg-card/50 backdrop-blur px-4 py-2 font-mono text-sm">
                <span className="text-primary">$</span>
                <span className="text-muted-foreground">npx create-agent-team</span>
                <span className="text-primary animate-blink">_</span>
              </div>
            </div>

            <h1 className="text-balance text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">
              Build{" "}
              <span className="text-primary retro-glow">
                AI teams
              </span>
              {" "}that work like yours
            </h1>
            
            <p className="mx-auto lg:mx-0 mt-6 max-w-xl text-pretty text-lg text-muted-foreground">
              Stop building isolated chatbots. Create teams of specialized agents that collaborate, 
              share memory, and get work done — exactly like your best employees.
            </p>

            <div className="mt-10 flex flex-col items-center lg:items-start justify-center lg:justify-start gap-4 sm:flex-row">
              <Button size="lg" className="gap-2 h-12 px-6 font-mono text-sm bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(0,212,255,0.4)] transition-all">
                Start building
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="lg" className="gap-2 h-12 px-6 font-mono text-sm border-border hover:border-primary hover:text-primary transition-all">
                <Play className="h-4 w-4" />
                Watch demo
              </Button>
            </div>

            {/* Quick stats */}
            <div className="mt-12 flex flex-wrap items-center justify-center lg:justify-start gap-8 font-mono text-sm">
              <div className="flex items-center gap-2">
                <span className="text-primary">{">"}</span>
                <span className="text-muted-foreground">50+ teams active</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-primary">{">"}</span>
                <span className="text-muted-foreground">Open source</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-primary">{">"}</span>
                <span className="text-muted-foreground">No code</span>
              </div>
            </div>
          </div>

          {/* Right content - Agent Network visualization */}
          <div className="relative">
            <div className="relative rounded-lg border border-border bg-card/30 backdrop-blur p-4 retro-border">
              {/* Window chrome */}
              <div className="flex items-center gap-2 mb-4 pb-4 border-b border-border">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/50" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
                  <div className="w-3 h-3 rounded-full bg-green-500/50" />
                </div>
                <span className="font-mono text-xs text-muted-foreground ml-2">agent-network.exe</span>
              </div>
              
              <AgentNetwork />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
