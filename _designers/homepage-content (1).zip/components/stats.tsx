import { Zap, Database, Shield, Cpu, Monitor } from "lucide-react"

const stats = [
  { icon: Zap, text: "Deploy in minutes" },
  { icon: Database, text: "Persistent memory" },
  { icon: Shield, text: "Human-in-the-loop" },
  { icon: Cpu, text: "All major LLMs" },
  { icon: Monitor, text: "Web & desktop" }
]

export function Stats() {
  return (
    <section className="border-t border-border px-6 py-12 relative">
      <div className="absolute inset-0 grid-pattern opacity-5" />
      <div className="relative mx-auto max-w-7xl">
        <div className="flex flex-wrap items-center justify-center gap-6 md:gap-10">
          {stats.map((stat, index) => (
            <div key={index} className="flex items-center gap-2 font-mono text-xs">
              <stat.icon className="h-4 w-4 text-primary" />
              <span className="text-muted-foreground">{stat.text}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
