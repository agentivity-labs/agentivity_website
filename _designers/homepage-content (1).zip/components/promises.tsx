import { Clock, Users, UserCheck } from "lucide-react"

const promises = [
  {
    icon: Clock,
    code: "01",
    title: "Automate what costs you time",
    description: "Design intelligent pipelines that chain steps automatically: data collection, analysis, writing, validation, notification."
  },
  {
    icon: Users,
    code: "02",
    title: "Agents that collaborate",
    description: "A single agent has limits. A team of coordinating agents has almost none. Sequential, parallel, or dynamic delegation."
  },
  {
    icon: UserCheck,
    code: "03",
    title: "Stay in control",
    description: "Agentivity knows when a human decision is needed. It pauses, asks you, and resumes automatically."
  }
]

export function Promises() {
  return (
    <section className="border-t border-border px-6 py-20 relative">
      <div className="absolute inset-0 grid-pattern opacity-5" />
      <div className="relative mx-auto max-w-7xl">
        <div className="grid gap-4 md:grid-cols-3">
          {promises.map((promise, index) => (
            <div
              key={index}
              className="group rounded-lg border border-border bg-card/30 backdrop-blur p-6 transition-all hover:border-primary/50 hover:shadow-[0_0_20px_rgba(0,212,255,0.1)]"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded border border-border bg-secondary/50 text-primary group-hover:border-primary/50 transition-colors">
                  <promise.icon className="h-5 w-5" />
                </div>
                <span className="font-mono text-xs text-muted-foreground">{promise.code}</span>
              </div>
              <h3 className="mb-2 font-semibold">{promise.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{promise.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
