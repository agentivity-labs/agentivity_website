import { Briefcase, Code2, Plug, BarChart3 } from "lucide-react"

const audiences = [
  {
    icon: Briefcase,
    profile: "Business Teams",
    code: "BIZ",
    benefit: "Automate your processes without writing a single line of code"
  },
  {
    icon: Code2,
    profile: "AI Developers",
    code: "DEV",
    benefit: "A design and testing environment for your LLM agents"
  },
  {
    icon: Plug,
    profile: "Integrators",
    code: "INT",
    benefit: "Connect Agentivity to your existing systems via an open API"
  },
  {
    icon: BarChart3,
    profile: "Managers",
    code: "MGR",
    benefit: "Real-time visibility on every execution, every decision"
  }
]

export function ForWho() {
  return (
    <section className="border-t border-border px-6 py-24 relative">
      <div className="absolute inset-0 grid-pattern opacity-5" />
      <div className="relative mx-auto max-w-7xl">
        <div className="mb-12 text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary">// Audience</p>
          <h2 className="mt-4 text-3xl font-bold tracking-tight md:text-4xl">
            Built for <span className="text-primary">everyone</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Whether you code or not, Agentivity adapts to how you work.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {audiences.map((audience, index) => (
            <div
              key={index}
              className="rounded-lg border border-border bg-card/30 backdrop-blur p-5 transition-all hover:border-primary/50 hover:shadow-[0_0_20px_rgba(0,212,255,0.1)]"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded border border-border bg-secondary/50 text-primary">
                  <audience.icon className="h-5 w-5" />
                </div>
                <span className="font-mono text-[10px] text-muted-foreground px-2 py-1 rounded bg-secondary/50 border border-border/50">
                  {audience.code}
                </span>
              </div>
              <h3 className="mb-2 font-semibold">{audience.profile}</h3>
              <p className="text-sm text-muted-foreground">{audience.benefit}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
