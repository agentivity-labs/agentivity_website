"use client"

import { useEffect, useRef, useState } from "react"
import { Bot, Brain, Zap, MessageSquare, Database, Search } from "lucide-react"

interface Agent {
  id: string
  name: string
  role: string
  icon: React.ReactNode
  x: number
  y: number
  color: string
}

interface Connection {
  from: string
  to: string
  active: boolean
}

const agents: Agent[] = [
  { id: "orchestrator", name: "Orchestrator", role: "Coordinator", icon: <Brain className="w-5 h-5" />, x: 50, y: 30, color: "#00d4ff" },
  { id: "analyst", name: "Analyst", role: "Data Processing", icon: <Database className="w-5 h-5" />, x: 20, y: 55, color: "#00ff94" },
  { id: "researcher", name: "Researcher", role: "Information", icon: <Search className="w-5 h-5" />, x: 80, y: 55, color: "#ff00d4" },
  { id: "communicator", name: "Communicator", role: "Interface", icon: <MessageSquare className="w-5 h-5" />, x: 35, y: 80, color: "#ffd400" },
  { id: "executor", name: "Executor", role: "Actions", icon: <Zap className="w-5 h-5" />, x: 65, y: 80, color: "#00ff94" },
]

const connections: Connection[] = [
  { from: "orchestrator", to: "analyst", active: false },
  { from: "orchestrator", to: "researcher", active: false },
  { from: "orchestrator", to: "communicator", active: false },
  { from: "orchestrator", to: "executor", active: false },
  { from: "analyst", to: "communicator", active: false },
  { from: "researcher", to: "executor", active: false },
]

export function AgentNetwork() {
  const [activeConnections, setActiveConnections] = useState<Set<string>>(new Set())
  const [pulsingAgent, setPulsingAgent] = useState<string | null>(null)
  const svgRef = useRef<SVGSVGElement>(null)

  useEffect(() => {
    const interval = setInterval(() => {
      const randomConnection = connections[Math.floor(Math.random() * connections.length)]
      const connectionId = `${randomConnection.from}-${randomConnection.to}`
      
      setActiveConnections(prev => new Set([...prev, connectionId]))
      setPulsingAgent(randomConnection.from)
      
      setTimeout(() => {
        setPulsingAgent(randomConnection.to)
      }, 500)
      
      setTimeout(() => {
        setActiveConnections(prev => {
          const next = new Set(prev)
          next.delete(connectionId)
          return next
        })
        setPulsingAgent(null)
      }, 1500)
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  const getAgentPosition = (id: string) => {
    const agent = agents.find(a => a.id === id)
    return agent ? { x: agent.x, y: agent.y } : { x: 0, y: 0 }
  }

  return (
    <div className="relative w-full aspect-[4/3] max-w-2xl mx-auto">
      {/* Background grid */}
      <div className="absolute inset-0 grid-pattern opacity-30 rounded-lg" />
      
      {/* Glow effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-primary/20 rounded-full blur-[100px] animate-pulse-glow" />
      
      {/* SVG for connections */}
      <svg 
        ref={svgRef}
        className="absolute inset-0 w-full h-full"
        viewBox="0 0 100 100"
        preserveAspectRatio="xMidYMid meet"
      >
        <defs>
          <linearGradient id="connectionGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.2" />
            <stop offset="50%" stopColor="#00d4ff" stopOpacity="1" />
            <stop offset="100%" stopColor="#00d4ff" stopOpacity="0.2" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="1" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        
        {/* Connection lines */}
        {connections.map((conn) => {
          const from = getAgentPosition(conn.from)
          const to = getAgentPosition(conn.to)
          const connectionId = `${conn.from}-${conn.to}`
          const isActive = activeConnections.has(connectionId)
          
          return (
            <g key={connectionId}>
              {/* Base line */}
              <line
                x1={from.x}
                y1={from.y}
                x2={to.x}
                y2={to.y}
                stroke="currentColor"
                strokeWidth="0.3"
                className="text-border"
              />
              
              {/* Active glow line */}
              {isActive && (
                <line
                  x1={from.x}
                  y1={from.y}
                  x2={to.x}
                  y2={to.y}
                  stroke="#00d4ff"
                  strokeWidth="0.8"
                  filter="url(#glow)"
                  className="animate-pulse"
                  strokeDasharray="2 2"
                >
                  <animate
                    attributeName="stroke-dashoffset"
                    from="4"
                    to="0"
                    dur="0.5s"
                    repeatCount="indefinite"
                  />
                </line>
              )}
              
              {/* Data packet animation */}
              {isActive && (
                <circle r="1" fill="#00d4ff" filter="url(#glow)">
                  <animateMotion
                    dur="0.8s"
                    repeatCount="1"
                    path={`M${from.x},${from.y} L${to.x},${to.y}`}
                  />
                </circle>
              )}
            </g>
          )
        })}
      </svg>
      
      {/* Agent nodes */}
      {agents.map((agent) => (
        <div
          key={agent.id}
          className="absolute transform -translate-x-1/2 -translate-y-1/2 group"
          style={{ 
            left: `${agent.x}%`, 
            top: `${agent.y}%`,
          }}
        >
          {/* Pulse ring */}
          <div 
            className={`absolute inset-0 rounded-full transition-all duration-300 ${
              pulsingAgent === agent.id 
                ? 'animate-ping opacity-50' 
                : 'opacity-0'
            }`}
            style={{ backgroundColor: agent.color }}
          />
          
          {/* Node */}
          <div 
            className={`relative flex items-center justify-center w-12 h-12 md:w-14 md:h-14 rounded-lg border transition-all duration-300 ${
              pulsingAgent === agent.id 
                ? 'border-primary shadow-[0_0_20px_rgba(0,212,255,0.5)]' 
                : 'border-border hover:border-primary/50'
            }`}
            style={{
              backgroundColor: 'var(--card)',
              boxShadow: pulsingAgent === agent.id ? `0 0 30px ${agent.color}40` : undefined
            }}
          >
            <span style={{ color: agent.color }}>{agent.icon}</span>
          </div>
          
          {/* Label */}
          <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 text-center opacity-0 group-hover:opacity-100 transition-opacity">
            <p className="text-xs font-mono text-primary whitespace-nowrap">{agent.name}</p>
            <p className="text-[10px] text-muted-foreground whitespace-nowrap">{agent.role}</p>
          </div>
        </div>
      ))}
      
      {/* Terminal status */}
      <div className="absolute bottom-4 left-4 right-4">
        <div className="bg-card/80 backdrop-blur border border-border rounded px-3 py-2 font-mono text-xs">
          <span className="text-muted-foreground">[SYSTEM]</span>
          <span className="text-primary"> Agent network active</span>
          <span className="text-muted-foreground"> — </span>
          <span className="text-green-400">{agents.length} nodes</span>
          <span className="text-muted-foreground"> | </span>
          <span className="text-primary">{connections.length} connections</span>
          <span className="animate-blink text-primary">_</span>
        </div>
      </div>
    </div>
  )
}
