import { 
  Workflow, 
  Brain, 
  GitBranch, 
  UserPlus, 
  MessageSquare, 
  Sparkles, 
  Bot 
} from "lucide-react"

const features = [
  {
    icon: Workflow,
    title: "Visual Workflow Editor",
    code: "WFE",
    description: "Build automations with drag-and-drop. Connect agents, tools and conditions on an intuitive canvas."
  },
  {
    icon: Brain,
    title: "Agents with Memory",
    code: "MEM",
    description: "Each agent remembers context from past conversations. Learns and improves over time."
  },
  {
    icon: GitBranch,
    title: "Multi-Mode Teams",
    code: "TMD",
    description: "Sequential handoffs, parallel processing, dynamic delegation, or manager-led coordination."
  },
  {
    icon: UserPlus,
    title: "Human-in-the-Loop",
    code: "HIL",
    description: "Agents can request approval, submit forms, or notify you — without leaving context."
  },
  {
    icon: MessageSquare,
    title: "Real-Time Chat",
    code: "RTC",
    description: "Converse with agents while they work. Follow progress, ask questions, adjust course."
  },
  {
    icon: Sparkles,
    title: "Prompt Studio",
    code: "PST",
    description: "Write, test and optimize prompts. Compare versions, measure performance."
  },
  {
    icon: Bot,
    title: "AI Editor Assistant",
    code: "AEA",
    description: "An assistant that understands your workflow. Suggests steps, configures nodes for you."
  }
]

export function Features() {
  return (
    <section id="features" className="border-t border-border px-6 py-24 relative">
      {/* Background */}
      <div className="absolute inset-0 grid-pattern opacity-10" />
      
      <div className="relative mx-auto max-w-7xl">
        <div className="mb-16 text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary">// Capabilities</p>
          <h2 className="mt-4 text-3xl font-bold tracking-tight md:text-4xl">
            Everything to orchestrate{" "}
            <span className="text-primary">AI agents</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            A complete platform to design, test and deploy intelligent automations.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group rounded-lg border border-border bg-card/30 backdrop-blur p-5 transition-all hover:border-primary/50 hover:shadow-[0_0_20px_rgba(0,212,255,0.1)]"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex h-10 w-10 items-center justify-center rounded border border-border bg-secondary/50 text-primary group-hover:border-primary/50 transition-colors">
                  <feature.icon className="h-5 w-5" />
                </div>
                <span className="font-mono text-[10px] text-muted-foreground px-2 py-1 rounded bg-secondary/50 border border-border/50">
                  {feature.code}
                </span>
              </div>
              
              <h3 className="mb-2 font-semibold">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
