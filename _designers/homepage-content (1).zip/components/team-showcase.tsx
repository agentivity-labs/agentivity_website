"use client"

import { Users, Bot, Brain, Zap, MessageSquare, FileSearch, Mail, ShoppingCart, HeadphonesIcon, TrendingUp } from "lucide-react"
import { useState } from "react"

const teamExamples = [
  {
    name: "Customer Success Squad",
    code: "CSS-001",
    description: "Handle support tickets, qualify leads, and nurture relationships 24/7",
    agents: [
      { icon: HeadphonesIcon, role: "Support Agent", status: "ACTIVE" },
      { icon: MessageSquare, role: "Chat Specialist", status: "ACTIVE" },
      { icon: TrendingUp, role: "Success Manager", status: "STANDBY" },
    ],
    metrics: { tasks: "2,847", uptime: "99.9%", savings: "85%" },
  },
  {
    name: "Content Factory",
    code: "CTF-002",
    description: "Research, write, review and publish content at scale",
    agents: [
      { icon: FileSearch, role: "Researcher", status: "ACTIVE" },
      { icon: Brain, role: "Writer", status: "ACTIVE" },
      { icon: Bot, role: "Editor", status: "ACTIVE" },
    ],
    metrics: { tasks: "1,203", uptime: "99.7%", savings: "10x" },
  },
  {
    name: "Sales Dream Team",
    code: "SDT-003",
    description: "Prospect, qualify, engage and close deals automatically",
    agents: [
      { icon: Mail, role: "Outreach Agent", status: "ACTIVE" },
      { icon: Users, role: "Qualifier", status: "STANDBY" },
      { icon: ShoppingCart, role: "Closer", status: "ACTIVE" },
    ],
    metrics: { tasks: "4,521", uptime: "99.8%", savings: "3x" },
  },
]

export function TeamShowcase() {
  const [hoveredTeam, setHoveredTeam] = useState<string | null>(null)

  return (
    <section id="teams" className="px-6 py-24 md:py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 grid-pattern opacity-10" />
      
      <div className="relative mx-auto max-w-7xl">
        <div className="text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary">// Team Templates</p>
          <h2 className="mt-4 text-balance text-3xl font-bold tracking-tight md:text-5xl">
            Assemble teams like you&apos;d build a{" "}
            <span className="text-primary">startup</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-muted-foreground">
            Each agent has a role, memory, and expertise. Together, they collaborate, hand off tasks, 
            and get things done — just like a real team.
          </p>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {teamExamples.map((team) => (
            <div
              key={team.name}
              className="group relative overflow-hidden rounded-lg border border-border bg-card/50 backdrop-blur transition-all hover:border-primary/50"
              onMouseEnter={() => setHoveredTeam(team.code)}
              onMouseLeave={() => setHoveredTeam(null)}
              style={{
                boxShadow: hoveredTeam === team.code ? '0 0 30px rgba(0,212,255,0.15)' : undefined
              }}
            >
              {/* Terminal header */}
              <div className="flex items-center justify-between border-b border-border px-4 py-3 bg-card/80">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500/50" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500/50" />
                  </div>
                  <span className="font-mono text-xs text-muted-foreground ml-2">{team.code}</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="font-mono text-xs text-green-400">ONLINE</span>
                </div>
              </div>

              <div className="p-5">
                {/* Team header */}
                <div className="mb-5">
                  <h3 className="text-lg font-semibold">{team.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{team.description}</p>
                </div>

                {/* Agent list - terminal style */}
                <div className="mb-5 space-y-2 font-mono text-xs">
                  {team.agents.map((agent, idx) => (
                    <div 
                      key={agent.role} 
                      className="flex items-center gap-3 py-2 px-3 rounded bg-secondary/30 border border-border/50"
                    >
                      <span className="text-muted-foreground">{String(idx + 1).padStart(2, '0')}</span>
                      <agent.icon className="h-4 w-4 text-primary" />
                      <span className="flex-1 text-foreground">{agent.role}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                        agent.status === 'ACTIVE' 
                          ? 'bg-green-500/20 text-green-400' 
                          : 'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {agent.status}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-3 gap-3 pt-4 border-t border-border">
                  <div className="text-center">
                    <p className="font-mono text-xs text-muted-foreground">TASKS</p>
                    <p className="font-mono text-sm text-primary">{team.metrics.tasks}</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono text-xs text-muted-foreground">UPTIME</p>
                    <p className="font-mono text-sm text-green-400">{team.metrics.uptime}</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono text-xs text-muted-foreground">ROI</p>
                    <p className="font-mono text-sm text-primary">{team.metrics.savings}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-12 text-center">
          <p className="font-mono text-sm text-muted-foreground">
            <span className="text-primary">{">"}</span> These are templates. Design the team that fits{" "}
            <span className="text-primary">your</span> business.
          </p>
        </div>
      </div>
    </section>
  )
}
