"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Mail, MessageSquare, Building2, ArrowRight, Terminal } from "lucide-react"

const inquiryTypes = [
  { id: "demo", label: "Request a demo", icon: MessageSquare, code: "DEM" },
  { id: "services", label: "Professional services", icon: Building2, code: "SVC" },
  { id: "partnership", label: "Partnership inquiry", icon: Mail, code: "PTR" },
]

export default function ContactPage() {
  const [selectedType, setSelectedType] = useState("demo")
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24">
        <section className="px-6 py-16 md:py-24 relative">
          <div className="absolute inset-0 grid-pattern opacity-10" />
          <div className="relative mx-auto max-w-4xl">
            <div className="text-center mb-12">
              <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary mb-4">// Contact</p>
              <h1 className="text-balance text-4xl font-bold tracking-tight md:text-5xl">
                Let&apos;s <span className="text-primary">talk</span>
              </h1>
              <p className="mt-4 text-lg text-muted-foreground">
                Whether you want a demo, need professional services, or are interested in partnering — we&apos;d love to hear from you.
              </p>
            </div>

            {submitted ? (
              <div className="rounded-lg border border-border bg-card/50 backdrop-blur overflow-hidden">
                <div className="flex items-center justify-between border-b border-border px-4 py-3 bg-card/80">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-red-500/50" />
                      <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50" />
                      <div className="w-2.5 h-2.5 rounded-full bg-green-500/50" />
                    </div>
                    <span className="font-mono text-xs text-muted-foreground ml-2">message-sent.log</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-green-400" />
                    <span className="font-mono text-xs text-green-400">SUCCESS</span>
                  </div>
                </div>
                <div className="p-12 text-center">
                  <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-lg border border-primary/50 bg-primary/10 text-primary mb-6">
                    <Mail className="h-8 w-8" />
                  </div>
                  <h2 className="text-2xl font-bold">Message received</h2>
                  <p className="mt-4 text-muted-foreground font-mono text-sm">
                    <span className="text-primary">{">"}</span> We&apos;ll get back to you within 24 hours<span className="text-primary animate-blink">_</span>
                  </p>
                </div>
              </div>
            ) : (
              <div className="grid md:grid-cols-5 gap-6">
                {/* Inquiry type selection */}
                <div className="md:col-span-2 space-y-4">
                  <p className="font-mono text-xs uppercase tracking-wider text-primary">// How can we help?</p>
                  {inquiryTypes.map((type) => (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => setSelectedType(type.id)}
                      className={`w-full flex items-center gap-4 rounded-lg border p-4 text-left transition-all ${
                        selectedType === type.id
                          ? "border-primary bg-primary/5 shadow-[0_0_15px_rgba(0,212,255,0.1)]"
                          : "border-border bg-card/50 hover:border-border hover:bg-card/80"
                      }`}
                    >
                      <type.icon className={`h-5 w-5 ${selectedType === type.id ? "text-primary" : "text-muted-foreground"}`} />
                      <span className={`flex-1 ${selectedType === type.id ? "font-medium text-foreground" : "text-muted-foreground"}`}>
                        {type.label}
                      </span>
                      <span className={`font-mono text-[10px] px-2 py-1 rounded border ${
                        selectedType === type.id 
                          ? "bg-primary/10 border-primary/50 text-primary" 
                          : "bg-secondary/50 border-border/50 text-muted-foreground"
                      }`}>
                        {type.code}
                      </span>
                    </button>
                  ))}

                  <div className="pt-6 border-t border-border mt-6">
                    <p className="text-sm text-muted-foreground">
                      <span className="font-mono text-primary">{">"}</span> Prefer email? Reach us at{" "}
                      <a href="mailto:hello@agentivity.io" className="text-primary hover:underline font-mono">
                        hello@agentivity.io
                      </a>
                    </p>
                  </div>
                </div>

                {/* Contact form */}
                <div className="md:col-span-3 rounded-lg border border-border bg-card/50 backdrop-blur overflow-hidden">
                  <div className="flex items-center justify-between border-b border-border px-4 py-3 bg-card/80">
                    <div className="flex items-center gap-2">
                      <div className="flex gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full bg-red-500/50" />
                        <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50" />
                        <div className="w-2.5 h-2.5 rounded-full bg-green-500/50" />
                      </div>
                      <span className="font-mono text-xs text-muted-foreground ml-2">new-inquiry.form</span>
                    </div>
                  </div>
                  
                  <form onSubmit={handleSubmit} className="p-6">
                    <div className="grid gap-5">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="firstName" className="font-mono text-xs uppercase tracking-wider text-muted-foreground">First name</Label>
                          <Input id="firstName" placeholder="Jane" required className="bg-input border-border font-mono text-sm" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="lastName" className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Last name</Label>
                          <Input id="lastName" placeholder="Smith" required className="bg-input border-border font-mono text-sm" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email" className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Work email</Label>
                        <Input id="email" type="email" placeholder="jane@company.com" required className="bg-input border-border font-mono text-sm" />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="company" className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Company</Label>
                        <Input id="company" placeholder="Acme Inc." required className="bg-input border-border font-mono text-sm" />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="message" className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Message</Label>
                        <textarea
                          id="message"
                          className="flex min-h-[100px] w-full rounded-md border border-border bg-input px-3 py-2 font-mono text-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring resize-none"
                          placeholder={
                            selectedType === "demo"
                              ? "Tell us about your use case..."
                              : selectedType === "services"
                              ? "Describe your project..."
                              : "Tell us about your partnership idea..."
                          }
                          required
                        />
                      </div>

                      <Button type="submit" size="lg" className="w-full gap-2 font-mono text-sm bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(0,212,255,0.4)] transition-all">
                        Send message
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
