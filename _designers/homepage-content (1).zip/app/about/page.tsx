import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ArrowRight, Handshake, Building2, Code2, Globe, Terminal } from "lucide-react"
import Link from "next/link"

const partnerTypes = [
  {
    icon: Building2,
    title: "System Integrators",
    code: "SI",
    description: "Partner with us to bring AI agent orchestration to your enterprise clients. Get certified, access our partner portal, and co-sell solutions.",
  },
  {
    icon: Code2,
    title: "Technology Partners",
    code: "TP",
    description: "Integrate your tools and services with Agentivity. Build connectors, extend our platform, and reach our growing user base.",
  },
  {
    icon: Globe,
    title: "Resellers",
    code: "RS",
    description: "Bring Agentivity to new markets and regions. Benefit from volume pricing, marketing support, and dedicated partner success.",
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-24">
        {/* Hero */}
        <section className="px-6 py-16 md:py-24 relative">
          <div className="absolute inset-0 grid-pattern opacity-10" />
          <div className="relative mx-auto max-w-4xl text-center">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary mb-4">// About Us</p>
            <h1 className="text-balance text-4xl font-bold tracking-tight md:text-5xl">
              Building the future of{" "}
              <span className="text-primary retro-glow">AI collaboration</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground">
              Agentivity was born from a simple idea: AI agents are more powerful when they work together. 
              We&apos;re on a mission to make AI orchestration accessible to every business.
            </p>
          </div>
        </section>

        {/* Mission */}
        <section className="px-6 py-16 border-t border-border relative">
          <div className="absolute inset-0 grid-pattern opacity-5" />
          <div className="relative mx-auto max-w-4xl">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <p className="font-mono text-xs uppercase tracking-wider text-primary mb-2">// Mission</p>
                <h2 className="text-2xl font-bold md:text-3xl">Why We Build</h2>
                <p className="mt-4 text-muted-foreground">
                  We believe that the next wave of AI adoption will be driven by teams of specialized agents 
                  working together — not single-purpose chatbots. Agentivity provides the platform to design, 
                  deploy, and manage these agent teams at scale.
                </p>
                <p className="mt-4 text-muted-foreground">
                  Our visual-first approach means anyone can build sophisticated AI workflows, 
                  while our powerful engine ensures reliability and control for the most demanding use cases.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { value: "50+", label: "Companies using Agentivity" },
                  { value: "1M+", label: "Agent tasks executed" },
                  { value: "99.9%", label: "Uptime SLA" },
                  { value: "24/7", label: "Support available" },
                ].map((stat, idx) => (
                  <div key={idx} className="rounded-lg border border-border bg-card/50 backdrop-blur p-5 text-center hover:border-primary/50 transition-colors">
                    <p className="text-2xl font-bold font-mono text-primary">{stat.value}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Partnership */}
        <section id="partnership" className="px-6 py-16 border-t border-border relative">
          <div className="absolute inset-0 grid-pattern opacity-5" />
          <div className="relative mx-auto max-w-4xl">
            <div className="text-center mb-12">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-lg border border-primary/50 bg-primary/10 text-primary mb-4">
                <Handshake className="h-6 w-6" />
              </div>
              <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary mb-2">// Partnership</p>
              <h2 className="text-2xl font-bold md:text-3xl">Partner with Us</h2>
              <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
                Join our partner ecosystem and help businesses unlock the power of AI agent teams.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              {partnerTypes.map((partner) => (
                <div
                  key={partner.title}
                  className="rounded-lg border border-border bg-card/50 backdrop-blur p-5 hover:border-primary/50 hover:shadow-[0_0_20px_rgba(0,212,255,0.1)] transition-all"
                >
                  <div className="flex items-start justify-between mb-4">
                    <partner.icon className="h-6 w-6 text-primary" />
                    <span className="font-mono text-[10px] text-muted-foreground px-2 py-1 rounded bg-secondary/50 border border-border/50">
                      {partner.code}
                    </span>
                  </div>
                  <h3 className="font-semibold">{partner.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{partner.description}</p>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <Link href="/contact">
                <Button size="lg" className="gap-2 font-mono text-sm bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(0,212,255,0.4)] transition-all">
                  Become a Partner
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Open Source */}
        <section className="px-6 py-16 border-t border-border relative">
          <div className="absolute inset-0 grid-pattern opacity-5" />
          <div className="relative mx-auto max-w-4xl">
            <div className="rounded-lg border border-border bg-card/30 backdrop-blur overflow-hidden">
              {/* Terminal header */}
              <div className="flex items-center justify-between border-b border-border px-4 py-3 bg-card/80">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500/50" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500/50" />
                  </div>
                  <span className="font-mono text-xs text-muted-foreground ml-2">open-source.md</span>
                </div>
              </div>
              
              <div className="p-8 md:p-12 text-center">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary mb-4">// Open Source</p>
                <h2 className="text-2xl font-bold md:text-3xl">Built in the Open</h2>
                <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
                  We believe in transparency and community-driven development. Our core agent framework 
                  is open source, and we actively contribute to the AI ecosystem.
                </p>
                <div className="mt-8">
                  <Link
                    href="https://github.com/agentivity"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button variant="outline" size="lg" className="gap-2 font-mono text-sm border-border hover:border-primary hover:text-primary transition-all">
                      <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                        <path fillRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clipRule="evenodd" />
                      </svg>
                      View on GitHub
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
